# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, port):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # 
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = port
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
        print("Animal Shelter")

# Create method
    
    def create(self, data):
        print("creating")
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary 
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Read method

    def read(self, data):
        print("reading")
        dataDict = {}
        dictList = []
        
        if data is not None:
            result = self.database.animals.find(data)
            for animal in result:
                dataDict = animal
                dictList.append(dataDict)
        else:
            result = self.datase.animals.find()
            for animal in result:
                dataDict = animal
                dictList.append(dataDict)
    
        return dictList
    
# Update method

    def update(self, data, upData):
        print("updating")
        numUpdates = 0
        
        #Ensure that parameters aren't empty
        if upData and data is not None:
            #Find documents to be updated
            result = self.database.animals.find(data)
            
            #The number found from search will be updated
            numUpdates = result.count()
            
            #Iterate through results to update individully
            for animal in result:
                self.database.animals.update(data, upData)
                
            return numUpdates
        else: 
            raise Exception("Nothing to save, because data parameter is empty")
            return numUpdates
        
        
        
# Delete method
    
    def delete(self, data):
        print("deleting")
        numDeleted = 0
        
        if data is not None:
            result = self.database.animals.find(data)
            
            for animal in result:
                self.database.animals.delete_one(data)
                numDeleted += 1
            
            return numDeleted
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return numDeleted
                
        